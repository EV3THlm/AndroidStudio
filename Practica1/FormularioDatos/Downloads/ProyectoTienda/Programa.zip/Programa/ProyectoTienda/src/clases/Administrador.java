package clases;

public class Administrador extends Usuario{
    public Administrador(String nombre, String nombreUsuario, String password){
        super(nombre, nombreUsuario, password);
    }
}
