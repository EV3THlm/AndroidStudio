package clases;

public class Vendedor extends Usuario{
    public Vendedor(String nombre, String nombreUsuario, String password){
        super(nombre, nombreUsuario, password);
    }
}
