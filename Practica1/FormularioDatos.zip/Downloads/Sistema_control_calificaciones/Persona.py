class Persona:
    def __init__(self, nombre, apellido, password):
        self.nombre = nombre
        self.apellido = apellido
        self.password = password